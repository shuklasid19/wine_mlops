def test_generic():
    a = 2
    b = 2
    assert a!=b


  