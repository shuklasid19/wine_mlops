activate env

"conda activate wine"

created req file

install the req "pip freeze -> requirements.txt."

download the data place it on data given

'''bash git init '''

'''bash dvc init '''

dvc add data_given/winequality.csv

git add .

git commit -m ""

'''bash #it will track the data dvc add data_given/wine.csv ''' '''bash git add . ''' '''bash git commit -m "first commit" ''' '''bash git add . && git commit - "update readme file" '''

'''bash git remote add origin https://github.com/shuklasid19/mlops-wine1.git git branch -M main git push -u origin main '''